<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class AdminWallet extends Model
{
    //
}
